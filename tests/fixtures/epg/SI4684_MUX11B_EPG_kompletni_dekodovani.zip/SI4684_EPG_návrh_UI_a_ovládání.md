# Návrh EPG obrazovek – SI4684-FMDAB-Receiver

## Datový základ

- Zdroj: předaný `MUX11B_EPG_30min_full_carousel.zip`, uživatelem předaný archiv rekonstruovaných 70 MOT objektů.
- Parsováno všech 35 `epg` PI objektů a 5 `serviceInformation` SI objektů standardu ETSI TS 102 371 v3.1.1; celkem 1 087 programových záznamů, 30 ověřených PNG a MOT Directory.
- Rozpis je historický 11.–16. listopadu 2024. Všechny programové `timePoint` měly UTC čas a LTO +01:00. Simulace v náhledech je **12. listopadu 2024, 04:30** – nikoli nynější vysílání.
- 55 položek SI napříč 5 objekty znamená 11 opakovaně uvedených stanic; 10 jedinečných `bearer` identifikátorů. `Polskie Radio24` a `Chopin` sdílejí stejný identifikátor v poskytnutých datech – nutno ošetřit jako konflikt. EPG plán je v datech jen pro 7 identifikátorů služeb.
- Rozpis obsahuje překrývající se položky v jedné stanici; zachovat plánovaný začátek, délku a volitelné `actualTime` a záznamy svévolně neposouvat. Souběžné pořady vyžadují explicitní výběrovou politiku, příp. informaci o nejistotě.

## Zachování vzhledu projektu

Obrazovky 320×240 ILI9341 jsou vyobrazeny na PNG podle skutečných bitmap v `src/graphics.h`:

- Přehled a detail: `configurationbackground` (horní a spodní pás, modré gradienty).
- Seznam: `servicelistbackground` a původní selektor `selector` (304×20 na 9 řádcích).
- Barvy čerpají z `doTheme()` v `src/gui.cpp`, ukázka pro `CurrentTheme=0 / Elegant`: `ActiveColor`, `PrimaryColor`, `SecondaryColor`. Při implementaci se nemají hardcodovat, protože projekt podporuje 7 témat.
- Text vykreslovat stávajícím `tftPrintFixed`/TFT_eSPI, preferovat částečné překreslování `FullLineSprite` 304×20. Nepřidávat nový celoobrazovkový framebuffer (napjatá RAM).
- Vyzkoušet podporu UTF-8 a polských znaků v existujícím fontu; případně použít odpovídající glyph fallback s jasným příznakem nepodporovaného znaku.

## Tři obrazovky

1. `EPG přehled`: logo právě poslouchané stanice, jméno, volitelně datum/čas, NOW s intervalem a progressem a další podle SPI programu. Při konfliktu více aktivních intervalů rozhodovat deterministicky podle zadání; nevydávat historický či nejistý záznam za živý.
2. `EPG seznam`: stejná devítiřádková stránka a 20px řádky jako existující seznam služeb. Vlevo začátek (HH:MM), vpravo název; vybraný řádek používá `selector`. Přepínání dne beze změny naladěné stanice.
3. `EPG detail`: název, stanice, čas a delší popis se stránkováním. Volitelný obrázek z MOT podle skutečné vazby v Service Information / Directory, nikoli pouze podle pořadí TID.

## Doporučené ovládání – rozšíření, nikoli současná funkce

| Ovladač | Na běžné obrazovce | V EPG přehledu/seznamu/detailu |
| --- | --- | --- |
| SL krátce | **Beze změny:** zobrazit/přepnout Slideshow | návrat z EPG; bez resetu SLS collector |
| SL dlouze, ~1 s | **Nové:** otevřít EPG | zavřít EPG |
| Enkodér 1, otočení | **Beze změny:** ladění/paměti, v seznamu pohyb | pohyb v seznamu EPG; v detailu posun textu |
| Enkodér 1, krátký stisk | **Beze změny:** výběr stanice / menu | přehled→seznam, seznam→detail, detail→seznam |
| Enkodér 1, dlouhý stisk | **Beze změny:** scan mimo EPG | nespouštět scan; volitelně skok na aktuální čas |
| Enkodér 2, otočení | **Beze změny:** výběr služby / FM jemný krok | přepnout den v seznamu, v detailu přepnout sousední pořad; nikdy nenaladit jinou stanici |
| Enkodér 2, stisk | **Beze změny:** overlay hlasitosti | zachovat overlay hlasitosti, po zavření návrat do EPG |
| MODE krátce | **Beze změny:** tune mode; z podstránky návrat | o úroveň zpět, z přehledu do hlavního rádia |
| MODE dlouze | **Beze změny:** nastavení | beze změny, návrat bez ztráty aktuálního audio příjmu |
| Standby dlouze | **Beze změny:** deep sleep | zachovat prioritu standby |

Krátký vs dlouhý stisk SL dnes firmware nerozlišuje – `buttonEdge(SLBUTTON, slArmed)` volá slideshow okamžitě. Navrhované nové držení >1 s vyžaduje **neblokující press-tracker** s potlačením dvojí události; při krátkém stisku může být reakce až na uvolnění. Bootovací kombinace se SL musí zůstat zachovány.

## Omezení a datová logika na ESP32

- Po FFT/SPI routingu číst DSRV payload v omezeném stavu parseru, nedělat dlouhé hexdumpy, chránit audio+PAD SLS; obě MOT větve musí mít vlastní segmentový kontext.
- Zapisovat/číst zvolený SID (a GCC/ECC+EId+SCIdS) ze SPI `bearer` ID, nikoli jen název; při kolizi identit jako Radio24/Chopin označit jako nejednoznačné.
- Přijímač má pracovní MOT buffer ~50 KiB a přibližně 88 KiB volného heapu v polském testu. Cílem je **cache jednoho dne pro aktivní stanici a malá cache log**, bez ukládání 70 kompletních MOT objektů do interní RAM.
- Ověřit LTO/MJD/letní čas, stáří EPG, neúplné directory, výpadek MOT, chybné CRC a překrývající se relace. Zastaralá data se nesmí vydávat za NOW/NEXT.
- Podporu EPG přes PAD/X-PAD je možné později přidat jako druhý transportní adaptér sdílející SPI/MOT parser. Dodaná data potvrzují pouze packet-mode.

## Vytvořené vizualizace

- `SI4684_EPG_01_prehled_320x240.png`
- `SI4684_EPG_02_seznam_320x240.png`
- `SI4684_EPG_03_detail_320x240.png`
- `SI4684_EPG_vzhled_podle_projektu.png`

**Nejde o implementaci firmware:** jde o dekódovaná offline data a věrné návrhy grafického rozhraní a ovládací logiky. Zdrojový kód rádia na GitHubu zůstává nezměněn.
