#!/usr/bin/env python3
"""ETSI TS 102 371 v3 binary TLV extraction from full MOT SPI objects."""
from dataclasses import dataclass,field
from datetime import datetime,timedelta,timezone
from collections import Counter,defaultdict
import zipfile,json,os,csv,re
from pathlib import Path

ZIP=Path('/mnt/data/MUX11B_EPG_decoded_70_objects.zip')
OUT=Path('/mnt/data/epg_spi_fully_decoded')
OUT.mkdir(exist_ok=True)
ELEMENTS={0x02:'epg',0x03:'serviceInformation',0x04:'tokenTable',0x05:'defaultBearerURI',0x06:'defaultLanguage',0x10:'shortName',0x11:'mediumName',0x12:'longName',0x13:'mediaDescription',0x14:'genre',0x16:'keywords',0x17:'memberOf',0x18:'link',0x19:'location',0x1a:'shortDescription',0x1b:'longDescription',0x1c:'programme',0x20:'programmeGroups',0x21:'schedule',0x23:'programmeGroup',0x24:'scope',0x25:'serviceScope',0x26:'ensemble',0x28:'service',0x29:'bearer',0x2b:'multimedia',0x2c:'time',0x2d:'bearer',0x2e:'programmeEvent',0x2f:'relativeTime',0x31:'radiodns',0x32:'geolocation',0x33:'country',0x34:'point',0x35:'polygon',0x36:'onDemand'}
ATTRS={
'serviceInformation':{0x80:'version',0x81:'creationTime',0x82:'originator',0x83:'serviceProvider'},
'ensemble':{0x80:'id'},'service':{0x80:'version'},
'programmeGroups':{0x80:'version',0x81:'creationTime',0x82:'originator'},
'programmeGroup':{0x80:'id',0x81:'shortId',0x82:'version',0x83:'type',0x84:'numOfItems'},
'schedule':{0x80:'version',0x81:'creationTime',0x82:'originator'},
'scope':{0x80:'startTime',0x81:'stopTime'},
'serviceScope':{0x80:'id'},
'programme':{0x80:'id',0x81:'shortId',0x82:'version',0x83:'recommendation',0x84:'broadcast',0x86:'xml:lang'},
'programmeEvent':{0x80:'id',0x81:'shortId',0x82:'version',0x83:'recommendation',0x84:'broadcast'},
'time':{0x80:'time',0x81:'duration',0x82:'actualTime',0x83:'actualDuration'},
'relativeTime':{0x80:'time',0x81:'duration',0x82:'actualTime',0x83:'actualDuration'},
'multimedia':{0x80:'mimeValue',0x81:'xml:lang',0x82:'url',0x83:'type',0x84:'width',0x85:'height'},
'bearer':{0x80:'id',0x82:'url'},
'memberOf':{0x80:'id',0x81:'shortId',0x82:'index'},
'link':{0x80:'uri',0x81:'mimeValue',0x82:'xml:lang',0x83:'description',0x84:'expiryTime'},
'genre':{0x80:'href',0x81:'type'},
'shortName':{0x80:'xml:lang'},'mediumName':{0x80:'xml:lang'},'longName':{0x80:'xml:lang'},
'shortDescription':{0x80:'xml:lang'},'longDescription':{0x80:'xml:lang'},
}
TEXT_ATTRS={'originator','serviceProvider','id','xml:lang','mimeValue','url','description','href','uri'}
TIME_ATTRS={'creationTime','startTime','stopTime','time','actualTime','expiryTime'}
DURATIONS={'duration','actualDuration'}

@dataclass
class Node:
    tag:int
    name:str
    pos:int
    attrs:dict=field(default_factory=dict)
    nodes:list=field(default_factory=list)
    text:str=''
    raw:bytes=b''
    tokens:dict=field(default_factory=dict)
    
    def descendants(self,name):
        for n in self.nodes:
            if n.name==name:yield n
            yield from n.descendants(name)
    def first(self,name):
        return next(self.descendants(name),None)
    def gettext(self,name):
        x=self.first(name);return x.text if x else ''

class TLVError(Exception): pass

def read_tlv(data, pos, limit):
    if pos+2>limit:raise TLVError(f'TLV header overflow {pos} {limit}')
    tag,n=data[pos],data[pos+1];idx=pos+2
    if n==0xfe:
        if idx+2>limit:raise TLVError('extended 2 overflow')
        n=int.from_bytes(data[idx:idx+2],'big');idx+=2
    elif n==0xff:
        if idx+3>limit:raise TLVError('extended 3 overflow')
        n=int.from_bytes(data[idx:idx+3],'big');idx+=3
    if idx+n>limit:raise TLVError(f'TLV data overflow tag={tag:02x} pos={pos} len={n} remain={limit-idx}')
    return tag,idx,idx+n

def token_parse(data):
    table={}; i=0
    while i<len(data):
        if i+2>len(data):raise TLVError('truncated token')
        k,n=data[i],data[i+1];i+=2
        if i+n>len(data):raise TLVError('token overflow')
        table[k]=data[i:i+n].decode('utf-8',errors='replace');i+=n
    return table

def utf_decode(b,token):
    out=bytearray()
    for v in b:
        if v in token:out.extend(token[v].encode('utf-8'))
        else:out.append(v)
    return out.decode('utf-8',errors='replace')

def timepoint(b):
    # ETSI TS 102371 v3.1: 1 reserved, 17 MJD, 1 UTC-form, 1 LTO flag, 11/27 UTC bits, optional 8 LTO bits; trailing padding possible
    def bits(offset,n):
        allbits=int.from_bytes(b,'big')
        return (allbits>>(8*len(b)-offset-n)) & ((1<<n)-1)
    if len(b)<4:return None
    mjd=bits(1,17);longfmt=bits(18,1);ltoflag=bits(19,1)
    hour=bits(20,5);minute=bits(25,6)
    second=bits(31,6) if longfmt else 0
    used=20+(27 if longfmt else 11)
    # The time point is padded to a whole byte before the separate LTO byte.
    used=(used+7)//8*8
    offbit=bits(used,8) if ltoflag and 8*len(b)>=used+8 else 0
    if ltoflag:
        hrs=(offbit & 31)*0.5
        off=-hrs if offbit & 0x20 else hrs
    else: off=0
    try: dt=datetime(1858,11,17,tzinfo=timezone.utc)+timedelta(days=mjd,hours=hour,minutes=minute,seconds=second)
    except Exception:return None
    return {'utc':dt.isoformat(timespec='seconds'), 'local':(dt+timedelta(hours=off)).strftime('%Y-%m-%d %H:%M:%S'), 'offset_hours':off,'mjd':mjd}

def dec_attr(name,key,b):
    if key in TIME_ATTRS and name!='relativeTime':return timepoint(b) or b.hex()
    if key in DURATIONS or (name=='relativeTime' and key in {'time','actualTime'}):return int.from_bytes(b,'big')
    if key in {'shortId','version','width','height','index','numOfItems'}:return int.from_bytes(b,'big')
    if key in {'broadcast','recommendation','type'}:return int.from_bytes(b,'big')
    if key in {'id'} and name in {'serviceScope','bearer','ensemble'}:return b.hex()
    if key in TEXT_ATTRS:return b.decode('utf-8',errors='replace')
    return b.hex()

def parse_node(data,pos=0,limit=None, token=None,depth=0):
    if limit is None:limit=len(data)
    if depth>24:raise TLVError('max depth')
    tag,start,end=read_tlv(data,pos,limit)
    name=ELEMENTS.get(tag,f'tag_{tag:02X}')
    node=Node(tag,name,pos,raw=data[start:end]); idx=start
    if name=='tokenTable':
        node.tokens=token_parse(data[start:end]);return node,end
    if name=='defaultBearerURI' or name=='defaultLanguage':
        node.text=data[start:end].hex() if name=='defaultBearerURI' else data[start:end].decode('utf-8',errors='replace')
        return node,end
    if name=='tag_01':
        node.text=utf_decode(data[start:end],token or {});return node,end
    while idx<end:
        childtag,dstart,dend=read_tlv(data,idx,end)
        if childtag>=0x80:
            key=ATTRS.get(name,{}).get(childtag,f'attr_{childtag:02X}')
            node.attrs[key]=dec_attr(name,key,data[dstart:dend])
            idx=dend
        else:
            child,idx=parse_node(data,idx,end,token if token is not None else {},depth+1)
            node.nodes.append(child)
            if child.name=='tokenTable':
                token=child.tokens
            elif child.name=='tag_01':
                node.text+=child.text
    return node,end

def asdict(n):
    return {'tag':n.name,'attrs':n.attrs,'text':n.text,'tokens':n.tokens,'children':[asdict(c) for c in n.nodes]}

def summaries(roots):
    allitems=[]; allserv=[]; counts=Counter(); issues=[]
    for tid,r in roots.items():
        counts[r.name]+=1
        if r.name=='epg':
            for sched in r.descendants('schedule'):
                scope=sched.first('scope')
                ss=scope.first('serviceScope') if scope else None
                sid_hex=ss.attrs.get('id','') if ss else ''
                for prog in sched.nodes:
                    if prog.name!='programme': continue
                    dates=[]
                    for loc in prog.descendants('location'):
                        for t in loc.nodes:
                            if t.name in ('time','relativeTime'):
                                dates.append({'type':t.name,**t.attrs})
                    line={'tid':tid,'sid':sid_hex,'name':prog.gettext('mediumName') or prog.gettext('longName') or prog.gettext('shortName'),
                         'mediumName':prog.gettext('mediumName'), 'longName':prog.gettext('longName'), 'shortName':prog.gettext('shortName'),
                          'shortDescription':prog.gettext('shortDescription'),'longDescription':prog.gettext('longDescription'),
                          'shortId':prog.attrs.get('shortId'), 'crid':prog.attrs.get('id'),
                         'time':dates,'scope':scope.attrs if scope else None,
                         'events':[{'name':e.gettext('mediumName') or e.gettext('longName'),'attrs':e.attrs} for e in prog.descendants('programmeEvent')]}
                    allitems.append(line)
        if r.name=='serviceInformation':
            for ensemble in r.descendants('ensemble'):
                for serv in ensemble.descendants('service'):
                    bearers=[]; medias=[]
                    for e in serv.descendants('bearer'):bearers.append(e.attrs)
                    for e in serv.descendants('multimedia'):medias.append(e.attrs)
                    allserv.append({'tid':tid,'serviceName':serv.gettext('mediumName') or serv.gettext('longName') or serv.gettext('shortName'),
                                    'short':serv.gettext('shortName'), 'medium':serv.gettext('mediumName'), 'long':serv.gettext('longName'), 'bearers':bearers,'medias':medias})
    return allitems,allserv,counts

if __name__=='__main__':
    z=zipfile.ZipFile(ZIP)
    roots={};errors={}
    for f in sorted(z.namelist()):
        if not f.endswith('.bin'):continue
        tid=f.split('TID_')[-1].split('.')[0]
        b=z.read(f)
        if b[0] not in (0x02,0x03):continue
        try:
            root,end=parse_node(b)
            if end!=len(b):raise TLVError('not all consumed')
            roots[tid]=root
        except Exception as e:errors[tid]=str(e)
    print('Parsed objects',len(roots),'errors',errors)
    items,services,counts=summaries(roots)
    print('Counts',counts,'programmes',len(items),'services',len(services))
    for p in items[:12]:print(p['tid'],p['sid'],p['name'][:50],p['time'][:1])
    for s in services[:14]:print('SERVICE',s)
    res={'source':ZIP.name,'count':dict(counts),'programmes':items,'services':services,'errors':errors}
    (OUT/'decoded.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
    for tid,root in roots.items():
        (OUT/f'{tid}.json').write_text(json.dumps(asdict(root),ensure_ascii=False,indent=2),encoding='utf-8')
