# Úplné dekódování poskytnutého MUX 11B SPI/EPG dumpu

Zdroj: přiložený 30minutový záznam a z něj sestavených 70 MOT objektů.

Dekódováno: 1087 záznamů pořadů, 35 objektů epg, 5 serviceInformation (55 výskytů služeb, 11 unikátních názvů), 30 PNG, 1 MOT Directory.
Rozpisy v datech mají datum 2024-11-11 až 2024-11-16; nejde o aktuální EPG pro rok 2026. Časy jsou podle binárně uloženého UTC a LTO (+01:00 v tomto vzorku), nikoli automaticky podle dnešního pásma PC.
Různé časy/délky se překrývají; zachována přenesená data, nikoli automaticky opravena. V SI se vyskytuje kolize bearer ID pro Polskie Radio24 a Chopin (40e2315332a3), proto je automatické mapování těchto dvou názvů nejednoznačné.

Obsah: `decoded.json` původní stromové souhrny, `all_programmes_1087.csv` / `.json` položky se stanicí/časy/popisem, `F6xx.json` úplné stromové objekty, `stations.json`, `mot_filename_mapping.json`, 30 PNG a extrahovaná MOT Directory.
Specifikace parseru: ETSI TS 102 371 v3.1.1 – TLV, tokenTable, časové údaje MJD/UTC/LTO, SI/PI.
Dostupná data neobsahují skutečný SPI/X-PAD přenos, jen packet-mode; integrace do Si4684 vyžaduje vlastní přenosovou vrstvu a RAM limity.
